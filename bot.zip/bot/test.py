# import sql3Funcs

# sql3Funcs.create_table('db/botDataBase.db', 'usersDB', id='TEXT', fname='TEXT', lname='TEXT', username='TEXT', language_code='TEXT')
# sql3Funcs.create_table('db/botDataBase.db', 'reportsDB', id='TEXT', reports='TEXT')

# goyda = '1, 2, 3, 4, 5, 6, 7, 8, 9'
# print(goyda.split(', '))

# from threading import Timer

# def timeout():
#     print('goyda')

# number_of_seconds = 10

# t = Timer(number_of_seconds, timeout)
# t.start()

# def timeout():
#     bot.send_message(chat_id=call.message.chat.id, text='После  вашего прошлого внесения экранного времени в бота прошло 24 часа, пришло время Для нового внесения!', reply_markup=twentyFourHReportKeyboard)

# t = Timer(oneDayTimer, timeout)
# t.start()

# @bot.callback_query_handler(func=lambda call: call.data == 'week_statistics')
# def WeekStatistics(call):
#     historyOfReports = sql3Funcs.get_from_table(database_name, reports_table, 'id', call.message.chat.id)
#     reportsArr = historyOfReports[1].split(', ')
#     print(reportsArr)
#     if len(historyOfReports) >= 7:
#         lastWeekArr = reportsArr[len(reportsArr)-7:]
#         lastWeekArr2 = []
#         for i in lastWeekArr:
#             lastWeekArr2.append(int(i))
#         lastWeekMean = statistics.mean(lastWeekArr2)
#         if sum(lastWeekArr2) <= 15:
#             bot.send_message(chat_id=call.message.chat.id, text=f'За эту неделю ты провёл в соц. сетях {sum(lastWeekArr2)} часов. Это очень хороший результат, продлжай в том же духе!')
#             print(1)
#         elif sum(lastWeekArr2) > 15 and sum(lastWeekArr) <= 25:
#             bot.send_message(chat_id=call.message.chat.id, text=f'За эту неделю ты провёл в соц. сетях {sum(lastWeekArr2)} часов. Данный результат весьма неплох. Ты тратил около трёх часов в день на соц сети. Ты большой молодец, продолжай в том же духе!')
#             print(2)
#         elif sum(lastWeekArr2) > 25 and sum(lastWeekArr) <= 30:
#             bot.send_message(chat_id=call.message.chat.id, text=f'За эту неделю ты провёл в соц. сетях {sum(lastWeekArr2)} часов. Это много, примерно 4 часа в день. Тебе есть куда расти, продолжай пользоваться ботом и улучшай свои результаты!')
#             print(3)
#         elif sum(lastWeekArr2) > 30:
#             bot.send_message(chat_id=call.message.chat.id, text=f'За эту неделю ты провёл в соц. сетях {sum(lastWeekArr2)} часов. Ты проводишь слишком много времени в соц. сетях, тебе нужно пересмотреть свой подход к их использванию. Продолжай работать над собой и улучшай свои показатели!')
#             print(4)
#     if len(historyOfReports) >= 14:
#         lastLastWeekArr = reportsArr[len(reportsArr)-14:len(reportsArr)-7]
#         lastLastWeekArr2 = []
#         for i in lastLastWeekArr:
#             lastLastWeekArr2.append(int(i))
#         lastLastWeekMean = statistics.mean(lastLastWeekArr2)
#         if sum(lastWeekArr2) > sum(lastLastWeekArr2):
#             bot.send_message(chat_id=call.message.chat.id, text=f'На этой неделе ты пользовался соц. сетями на {sum(lastWeekArr2)-sum(lastLastWeekArr2)} часа(-ов) больше, чем на прошлой неделе. Тебе нужно работать над собой, чтобы улучшать свои показатели.')
#         elif sum(lastWeekArr2) == sum(lastLastWeekArr2):
#             bot.send_message(chat_id=call.message.chat.id, text=f'На этой неделе ты пользовался соц. сетями ровно столько же, как и на прошлой неделе. Продолжай работать над собой, и у тебя всё полчучится!')
#         elif sum(lastWeekArr2) < sum(lastLastWeekArr2):
#             bot.send_message(chat_id=call.message.chat.id, text=f'На этой неделе ты пользовался соц. сетями на {sum(lastWeekArr2)-sum(lastLastWeekArr2)} часа(-ов) меньше, чем на прошлой неделе. Ты улучшил свои результаты, и это похвально!')