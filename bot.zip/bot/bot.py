import telebot
import sql3Funcs
from keyboards import *
import time
import soveti
from threading import Timer
import statistics


token = '8369137165:AAG5DInhONOZuf4U8S9Vi6Or59q-ejTSklc'
database_name = 'db/botDataBase.db'
users_table = 'usersDB'
reports_table = 'reportsDB'
oneDayTimer = 86400  #1 день - 86400 секунд

bot = telebot.TeleBot(token=token)







@bot.message_handler(commands=['start'])
def start_message(message):
    id = message.from_user.id

    fname = message.from_user.first_name
    if fname: fname = fname.replace('"', '').replace('\'', '')
    
    lname = message.from_user.last_name
    if lname: lname = lname.replace('"', '').replace('\'', '')

    lname = message.from_user.username
    languageCode = message.from_user.language_code
    username = message.from_user.username
    if not sql3Funcs.get_from_table(database_name, users_table, 'id', id):
        sql3Funcs.insert_into_table(database_name, users_table, id=id, fname=fname, lname=lname, username=username, language_code=languageCode)
        sql3Funcs.insert_into_table(database_name, reports_table, id=id, reports='')
    time.sleep(1.5)
    # bot.send_photo(chat_id=message.chat.id, photo=photo, caption='Добро пожаловать в монитор экранного времени\n Выберите один из пунктов меню', reply_markup=menuKeyboard)
    bot.send_message(chat_id=message.chat.id, text='Добро пожаловать в главное меню бота "Стоп интернет-зависимость".\n Задача бота - помогать бороться с интернет-зависимостью.\n Выберите один из пунктов меню: ', reply_markup=menuKeyboard)


@bot.callback_query_handler(func= lambda call: call.data == 'report')
def report_screenTime(call):
    bot.send_message(chat_id=call.message.chat.id, text='Введите количество времени, проведённого в соцсетях, в часах.\n Например: 2.5, 3.5, 4, 1.2')
    bot.register_next_step_handler(callback=report_screenTime2, message=call.message)
def report_screenTime2(message):
    try:
        reportScreenTime = float(message.text)
        print(reportScreenTime)
        if reportScreenTime < 0:
            raise Exception('NegativeTimeError')
        if reportScreenTime > 24:
            raise Exception('TooMuchTimeError')
    except ValueError:
        print('ValueError')
        bot.send_message(chat_id=message.from_user.id, text='Напишите корректное время в сообщении', reply_markup=afterUncorrectReportKeyboard)
    except Exception as exc:
        print(exc)
        bot.send_message(chat_id=message.from_user.id, text='Напишите корректное время в сообщении', reply_markup=afterUncorrectReportKeyboard)
        return
    getReports = sql3Funcs.get_from_table(database_name, reports_table, 'id', message.from_user.id)
    print(getReports)
    sql3Funcs.update_table(database_name, reports_table, 'id', message.from_user.id, reports=getReports[1]+str(reportScreenTime)+', ')
    sovetOfDay = soveti.sovetOfDay()
    bot.send_message(chat_id=message.from_user.id, text=f'Ваши данные были успишно приняты и сохранены ботом✅ \nСовет дня: {sovetOfDay}')
    bot.send_message(chat_id=message.from_user.id, text='Вы можете вернуться в главное меню', reply_markup=menuReturnKeyboard)

    def timeout():
        bot.send_message(chat_id=message.from_user.id, text='После  вашего прошлого внесения экранного времени в бота прошло 24 часа, пришло время Для нового внесения!', reply_markup=twentyFourHReportKeyboard)

    t = Timer(oneDayTimer, timeout)
    t.start()

@bot.callback_query_handler(func=lambda call: call.data == 'menu_return')
def menu_return(call):
    bot.send_message(chat_id=call.message.chat.id, text='Добро пожаловать в главное меню бота "Стоп интернет-зависимость".\n Задача бота - помогать бороться с интернет-зависимостью.\n Выберите один из пунктов меню: ', reply_markup=menuKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'creators')
def creators(call):
    bot.send_message(chat_id=call.message.chat.id, text='Создатели данного проекта: \n👤Бедрин Леонид \n👤Еремин Александр \n🔍Научный руководитель: Францкевич Мария Александровна', reply_markup=menuReturnKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'reports_history')
def reportsHistory(call):
    historyOfReports = sql3Funcs.get_from_table(database_name, reports_table, 'id', call.message.chat.id)
    for i in range(len(historyOfReports[1].split(', '))-1):
        bot.send_message(chat_id=call.message.chat.id, text=f'Отчёт за {i+1} день: {historyOfReports[1].split(", ")[i]} часов', reply_markup=menuReturnKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'courses')
def courses(call):
    bot.send_message(chat_id=call.message.chat.id, text='В данном разделе ты можешь прочитать курсы по борьбе с интернет-зависимостью, чтобы улучшить свои результаты и преодолеть зависимость.', reply_markup=coursesKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'course1')
def course1(call):
    course1 = '''Курс 1. «Цифровой детокс: старт»
Цель: Осознать масштабы интернет‑потребления и сделать первые шаги к снижению экранного времени.

День 1. Аудит времени
Задание: включите встроенную статистику экранного времени на телефоне на весь день.
Рефлексия: вечером запишите, сколько часов вы провели в сети и какие приложения съели больше всего времени.
Совет бота: Не судите себя строго — сегодня мы просто собираем данные.

День 2. Критическая точка
Задание: отметьте 2–3 ситуации за день, когда вы автоматически хватаетесь за телефон (например, в очереди, за едой, перед сном).
Действие: в эти моменты сделайте 5 глубоких вдохов вместо разблокировки экрана.
Совет бота: Замечать привычку — первый шаг к её изменению.

День 3. Цифровой завтрак
Задание: первые 30 минут после пробуждения не берите в руки гаджеты. Выпейте стакан воды, сделайте пару растяжек.
Рефлексия: запишите, какие мысли и ощущения были у вас утром без соцсетей.
Совет бота: Начните день со связи с собой, а не с экраном.

День 4. Правило 20‑20‑20
Обучение: каждые 20 минут работы за экраном смотрите 20 секунд на объект в 20 футах (~6 метрах) от вас.
Задание: поставьте 3 напоминания на день для выполнения правила.
Совет бота: Это снизит нагрузку на глаза и даст микропаузы для осознанности.

День 5. Вечер без экрана
За час до сна убери телефон в другую комнату. Вместо этого почитай книгу (бумажную или с e‑ink), поговори с близкими или послушай подкаст.
Оцените качество сна и утреннее самочувствие.
Финальное сообщение: Ты сделал первые шаги к балансу. Продолжай наблюдать за своими привычками!'''
    bot.send_message(chat_id=call.message.chat.id, text=course1, reply_markup=coursesMenuKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'course2')
def course2(call):
    course2 = '''Курс 2. «Фокус без отвлечений»
Цель: Научиться концентрироваться на задачах без постоянного переключения на соцсети и уведомления.

День 1. Инвентаризация уведомлений
Отключи все несущественные уведомления (игры, рассылки, неважные чаты). Оставь только звонки и сообщения от близких.
Установи режим «Не беспокоить» на время работы/учёбы.
Совет бота: Уведомления — это приглашения в чужой график. Выбирайте, на какие отвечать.

День 2. Техника Pomodoro
Работай 25 минут без отвлечений, затем 5 минут отдыха. Повторяй 4 раза, потом длинный перерыв (15–30 мин).
Выполни 2 помидора сегодня, используя таймер.
Совет бота: Во время помидора телефон должен лежать экраном вниз в другой части комнаты.

День 3. Одно дело за раз
Выбери одну небольшую задачу (уборка стола, ответ на письмо) и выполни её, не открывая других вкладок/приложений.
Сравни, сколько времени ушло на задачу с отвлечением и без него.
Совет бота: Многозадачность — миф. Глубокая работа эффективнее.

День 4. Цифровой минимализм
Удали 1–2 приложения, которые отнимают время, но не приносят ценности.
Создай «зону без телефона» дома (например, обеденный стол или диван в гостиной).
Совет бота: Меньше стимулов — больше фокуса.

День 5. План на завтра
Вечером запланируй 3 главные задачи на следующий день.
Утром начни с самой сложной задачи, используя технику Pomodoro.
Финальное сообщение: Ты освоил базовые инструменты концентрации. Применяй их ежедневно!'''
    bot.send_message(chat_id=call.message.chat.id, text=course2, reply_markup=coursesMenuKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'course3')
def course3(call):
    course3 = '''Курс 3. «Реальная жизнь в приоритете»
Цель: Наполнить жизнь офлайн‑активностями и укрепить реальные социальные связи.

День 1. Офлайн‑актив дня
Запланируй одно дело без гаджетов: прогулка в парке, рисование, игра с питомцем.
Сделай фото момента (не экрана!) и поделитесь им в личном дневнике или с другом.

Совет бота: «Наслаждайся процессом, а не лайками».

День 2. Живое общение
Позвони или встретьтся с одним человеком из твоего списка контактов. Поговори не о соцсетях, а о чём‑то личном (новости, планы, воспоминания).
Отметьте, какие эмоции ты испытал от живого общения.
Совет бота: Реальные связи питают душу сильнее виртуальных.

День 3. Творческий час

посвяти 60 минут хобби, которое не требует интернета: готовка, лепка, сборка пазла, игра на инструменте.
Отключи уведомления на всё время занятия.
Совет бота: Творчество — антидот от цифровой перегрузки.

День 4. Природа вместо экрана
Проведи минимум 30 минут на улице без телефона. Наблюдайте за птицами, деревьями, облаками.

запиши 3 вещи, которые вы заметили в окружающем мире.
Совет бота: Природа возвращает нас в настоящий момент.

День 5. План офлайн‑недели
Составь список из 5 офлайн‑активностей, которые хочешь попробовать на следующей неделе (настольная игра, мастер‑класс, велопрогулка и т. д.).
Договорись с кем‑то о совместном выполнении 1–2 пунктов.

Финальное сообщение: Ваша жизнь богаче, чем лента соцсетей. Наслаждайтесь каждым моментом вне экрана!'''
    bot.send_message(chat_id=call.message.chat.id, text=course3, reply_markup=coursesMenuKeyboard)

@bot.callback_query_handler(func=lambda call: call.data == 'courses_menu_return')
def courses_menu_return(call):

    bot.send_message(chat_id=call.message.chat.id, text='В данном разделе ты можешь прочитать курсы по борьбе с интернет-зависимостью, чтобы улучшить свои результаты и преодолеть зависимость.', reply_markup=coursesKeyboard)

# while True:
#     try:
#         bot.polling(none_stop=True, interval=0)
#     except Exception as exc:
#         print(exc)

bot.polling(none_stop=True, interval=0)