import telebot

menuKeyboard=telebot.types.InlineKeyboardMarkup(row_width=1)
menuKeyboard.add(
    telebot.types.InlineKeyboardButton(text='Внести данные', callback_data='report'),
    telebot.types.InlineKeyboardButton(text='Создатели', callback_data='creators'),
    telebot.types.InlineKeyboardButton(text='История отчётов', callback_data='reports_history'),
    # telebot.types.InlineKeyboardButton(text='Получить статистику за последнюю неделю', callback_data='week_statistics')
    telebot.types.InlineKeyboardButton(text='Курсы', callback_data='courses')
)

coursesKeyboard=telebot.types.InlineKeyboardMarkup(row_width=1)
coursesKeyboard.add(
    telebot.types.InlineKeyboardButton(text='📖Курс 1. Цифровой детокс', callback_data='course1'),
    telebot.types.InlineKeyboardButton(text='📖Курс 2. Фокус без отвлечений', callback_data='course2'),
    telebot.types.InlineKeyboardButton(text='📖Курс 3. Реальная жизнь в приоритете', callback_data='course3'),
    telebot.types.InlineKeyboardButton(text='⬅️Вернуться в главное меню⬅️', callback_data='menu_return')
)

coursesMenuKeyboard=telebot.types.InlineKeyboardMarkup(row_width=1)
coursesMenuKeyboard.add(telebot.types.InlineKeyboardButton(text='⬅️Вернуться в меню курсов⬅️', callback_data='courses_menu_return'))

menuReturnKeyboard=telebot.types.InlineKeyboardMarkup()
menuReturnKeyboard.add(telebot.types.InlineKeyboardButton(text='⬅️Вернуться в главное меню⬅️', callback_data='menu_return'))

afterUncorrectReportKeyboard = telebot.types.InlineKeyboardMarkup()
afterUncorrectReportKeyboard.add(telebot.types.InlineKeyboardButton(text='Внести данные', callback_data='report'))

twentyFourHReportKeyboard = telebot.types.InlineKeyboardMarkup()
twentyFourHReportKeyboard.add(telebot.types.InlineKeyboardButton(text='Внести данные', callback_data='report'))